from flask import *
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired


app = Flask(__name__)


@app.route('/load_photo', methods=['POST', 'GET'])
def form_sample():
    if request.method == 'GET':
        param = {}
        param['title'] = 'Отбор космонавтов'
        param['first_zag'] = 'Загрузка фотографии'
        param['two_zag'] = 'для участия в миссии'
        return render_template('file.html', **param)
    elif request.method == 'POST':
        param = {}
        param['title'] = 'Отбор космонавтов'
        param['first_zag'] = 'Загрузка фотографии'
        param['two_zag'] = 'для участия в миссии'
        param['photo'] = request.form['file']
        return render_template('file_2.html', **param)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')